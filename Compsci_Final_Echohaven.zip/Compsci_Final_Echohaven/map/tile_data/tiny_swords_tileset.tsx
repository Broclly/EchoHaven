<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tiny_swords_tileset" tilewidth="64" tileheight="64" tilecount="150" columns="10">
 <image source="../map_tilesets/tileset/tinyswords_tileset.png" width="640" height="1008"/>
</tileset>
